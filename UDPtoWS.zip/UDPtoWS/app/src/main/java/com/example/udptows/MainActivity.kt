package com.example.udptows

import android.annotation.SuppressLint
import android.content.pm.PackageManager
import android.location.Location
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationCallback
import com.google.android.gms.location.LocationRequest
import com.google.android.gms.location.LocationResult
import com.google.android.gms.location.LocationServices
import java.nio.charset.StandardCharsets
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : AppCompatActivity() {

    private lateinit var btnSendUDP: Button
    private lateinit var etip: EditText
    private lateinit var etport: EditText
    private lateinit var fusedLocationClient: FusedLocationProviderClient
    private lateinit var locationRequest: LocationRequest
    private lateinit var locationCallback: LocationCallback
    private lateinit var textViewLatitude: TextView
    private lateinit var textViewLongitude: TextView
    private lateinit var textViewAltitude: TextView

    private var isLocationUpdatesEnabled = false
    private var isSendingLocation = false

    companion object {
        private const val REQUEST_CODE_LOCATION_PERMISSION = 102
        private const val UPDATE_INTERVAL = 10000L
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        btnSendUDP = findViewById(R.id.btnSendUDP)
        etip = findViewById(R.id.etip)
        etport = findViewById(R.id.etport)
        textViewLatitude = findViewById(R.id.textViewLatitude)
        textViewLongitude = findViewById(R.id.textViewLongitude)
        textViewAltitude = findViewById(R.id.textViewAltitude)

        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this)

        locationRequest = LocationRequest.create().apply {
            interval = UPDATE_INTERVAL
            fastestInterval = UPDATE_INTERVAL / 2
            priority = LocationRequest.PRIORITY_HIGH_ACCURACY
        }

        locationCallback = object : LocationCallback() {
            override fun onLocationResult(locationResult: LocationResult) {
                val location = locationResult.lastLocation
                if (location != null) {
                    val latitude = location.latitude
                    val longitude = location.longitude
                    val altitude = location.altitude

                    textViewLatitude.text = "Latitud: $latitude"
                    textViewLongitude.text = "Longitud: $longitude"
                    textViewAltitude.text = "Altitud: $altitude"
                    val fechaHora = obtenerFechaHoraDeUbicacion(location)

                    val contenidoMensaje = "FH: $fechaHora Lat: $latitude Lon: $longitude Alt: $altitude"

                    val direccionIpDestino = etip.text.toString()
                    val puertoDestinostring = etport.text.toString()
                    val puertoDestino = puertoDestinostring.toInt()

                    enviarUbicacionUDP(direccionIpDestino, puertoDestino, contenidoMensaje)
                }
            }
        }

        btnSendUDP.setOnClickListener {
            if (!isSendingLocation) {
                iniciarActualizacionesDeUbicacion()
                isSendingLocation = true
                btnSendUDP.text = "Detener Envío"
            } else {
                detenerActualizacionesDeUbicacion()
                isSendingLocation = false
                btnSendUDP.text = "Iniciar Envío"
            }
        }
    }


    @SuppressLint("MissingPermission")
    private fun iniciarActualizacionesDeUbicacion() {
        if (ContextCompat.checkSelfPermission(
                this,
                android.Manifest.permission.ACCESS_FINE_LOCATION
            ) == PackageManager.PERMISSION_GRANTED
        ) {
            fusedLocationClient.requestLocationUpdates(
                locationRequest,
                locationCallback,
                null
            )
            isLocationUpdatesEnabled = true
        } else {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(android.Manifest.permission.ACCESS_FINE_LOCATION),
                REQUEST_CODE_LOCATION_PERMISSION
            )
        }
    }

    private fun detenerActualizacionesDeUbicacion() {
        if (isLocationUpdatesEnabled) {
            fusedLocationClient.removeLocationUpdates(locationCallback)
            isLocationUpdatesEnabled = false
        }
    }

    private fun obtenerFechaHoraDeUbicacion(location: Location): String {
        val formatoFechaHora = SimpleDateFormat("dd/MM/yyyy HH:mm:ss", Locale.getDefault())
        return formatoFechaHora.format(Date(location.time))
    }

    private fun enviarUbicacionUDP(ipDestino: String, puerto: Int, mensaje: String) {
        Thread {
            try {
                val socket = DatagramSocket()
                val address = InetAddress.getByName(ipDestino)
                val sendData = mensaje.toByteArray(StandardCharsets.UTF_8)
                val packet = DatagramPacket(sendData, sendData.size, address, puerto)

                socket.send(packet)
                socket.close()

                runOnUiThread {
                    Toast.makeText(this@MainActivity, "Mensaje Enviado por UDP", Toast.LENGTH_SHORT).show()
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }.start()
    }
}

